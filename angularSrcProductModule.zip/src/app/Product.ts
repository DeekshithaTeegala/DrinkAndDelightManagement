export class Product
{
    productId:number;
    productName:String;
    price:number;
    manufacturingdate:Date;
    expirydate:Date;
}