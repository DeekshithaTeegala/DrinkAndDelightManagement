import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Product } from '../Product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  
  prod:Observable<Product>;
  submitted = false;

  product:Product=new Product();
  constructor(private service:ProductService,private router:Router) { }

  ngOnInit(): void {
    this.prod=this.service.findProductById(this.product.productId);
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  newProduct(): void {
    this.submitted = false;
    this.product = new Product();
  }

  save() {
    this.service.addProduct(this.product).subscribe(data => console.log(data), error => console.log(error));
    this.product = new Product();
    this.reloadData();
  }

  reloadData() {
    this.prod = this.service.addProduct(this.product);
    // this.service.findProductById(this.product.productId).subscribe(data=>this.router.navigate(['display-product',this.product.productId]),
    //        error => alert(error.error.errorMessage));
    // this.gotoListWalletAccount();
   }

  // addProduct()
  // {
  //   console.log(this.prod);
  //   this.service.addProduct(this.prod).subscribe(data=>this.prod=data);
  //   this.flag=true;
  //   // this.service.addProduct(this.prod).subscribe(data=>this.router.navigate(['display-product',this.product.productId]),
  //   //       error => alert(error.error.errorMessage));
    
  //   // this.router.navigate(['display-product',this.product.productId])
    
    
    
  // }

}
