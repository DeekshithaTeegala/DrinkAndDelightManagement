import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';
import { DisplayProductComponent } from './display-product/display-product.component';
import { FindProductComponent } from './find-product/find-product.component';

const routes: Routes = [
  {
    path :'add',
    component: AddProductComponent,

  },
  {
    path: 'find',
    component: FindProductComponent,

  },
  
  {
    path: 'delete',
    component: DeleteProductComponent,

  },
  {
    path : 'display-product/:productId',
    component : DisplayProductComponent
  },
  {
    path : '',
    redirectTo : '/add',
    pathMatch : 'full'
  }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
