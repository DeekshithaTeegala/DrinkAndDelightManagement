import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../Product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {

  productId : number;
  product : Product=new Product();
  constructor(private service:ProductService,private router : Router,private route: ActivatedRoute) {
    this.productId=this.route.snapshot.params['productId'];
    console.log(this.productId);
    service.findProductById(this.productId).subscribe(data=>this.product=data);
    
  }

  ngOnInit(): void {
  }

}
