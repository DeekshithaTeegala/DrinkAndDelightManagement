import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../Product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-find-product',
  templateUrl: './find-product.component.html',
  styleUrls: ['./find-product.component.css']
})
export class FindProductComponent implements OnInit {

  productId : number;
  product : Product=new Product();
  constructor(private service:ProductService,private router:Router) { }

  ngOnInit(): void {
    this.findProduct(this.productId);
  }

  findProduct(productId:number)
  {
    
    this.service.findProductById(productId).subscribe(data=>this.product=data);
     this.service.findProductById(productId).subscribe(data=>this.router.navigate(['display-product',this.product.productId]),
           error => alert(error.error.errorMessage));
    
    // this.service.findProductById(this.productId).subscribe(data=>this.product=data);
   
  }

}
