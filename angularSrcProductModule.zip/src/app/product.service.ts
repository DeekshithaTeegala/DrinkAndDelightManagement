import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './Product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  constructor(private http:HttpClient) { }
  addProduct(product : Product ) : Observable<Product>
  {
    console.log("Service : "+product.productId);
    return this.http.post<Product>("http://localhost:9092/product",product);
  }

  deleteProductById(productId : number): Observable<Product>
  {
    console.log(" Id = "+productId);
    return this.http.delete<Product>("http://localhost:9092/product/"+productId);
    
  }

  findProductById(productId : number) : Observable<Product>
  {
    console.log(" Id = "+productId);
    return this.http.get<Product>("http://localhost:9092/product/"+productId);
  }
  
}
