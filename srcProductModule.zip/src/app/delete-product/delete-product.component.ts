import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Product } from '../Product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {

  // prod:Observable<Product>;
  submitted=false;

  productId : number;
  product : Product=new Product();
  constructor(private service:ProductService,private router:Router) { }
  
  ngOnInit(): void {
    // this.prod=this.service.deleteProductById(this.product.productId);
    

  }

  // newProduct(): void {
  //   this.submitted = false;
  //   this.product = new Product();
  // }

  deleteProduct(productId:number)
  {
    // this.submitted = true;
    this.service.deleteProductById(productId).subscribe(data => console.log(data),error => alert(error.error.errorMessage));
    
  }

 


  // onSubmit() {
  //   this.submitted = true;
  //   this.save();    
  // }

  // newProduct(): void {
  //   this.submitted = false;
  //   this.product = new Product();
  // }

  // save() {
  //   this.service.deleteProductById(this.productId).subscribe(data=>this.product=data);
  //   // this.product = new Product();
  //   // this.reloadData();
  // }

  // reloadData() {
  //   this.service.deleteProductById(this.productId);
  //   // this.service.findProductById(this.product.productId).subscribe(data=>this.router.navigate(['display-product',this.product.productId]),
  //   //        error => alert(error.error.errorMessage));
  //   // this.gotoListWalletAccount();
  //  }


}
